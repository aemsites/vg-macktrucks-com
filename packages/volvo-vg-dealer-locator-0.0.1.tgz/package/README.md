# VG Dealer Locator Widget

Embeddable React + TypeScript dealer locator built with Vite.

This project is a widget-first app intended to be mounted in host websites via a `mount(el, options)` API. It is not a Next.js app.

Local development uses the root Vite app shell in `index.html`. The embeddable package entry remains `src/embed.tsx`.

When embedded, the widget fills `100%` of the mount element. Hosts should set the desired width and height on the container passed to `mount(...)`; the widget layout is container-scoped and does not size itself from viewport units.

## Product Scope

Primary feature:
- Interactive map + dealer locator.
- Core user journey: find dealers and connect with them through a contact form.

Desktop v1 behavior:
- Full-container map background.
- Left floating sidebar with search, filters, radius slider, and dealer results.
- Right map controls: zoom in, zoom out, center on current location.
- Center on current location resolves the user coordinates into the active search center, updates the search input label, and re-filters dealers using that center.
- Dealer list stays empty until user submits a search.
- After search, dealer list shows all in-radius dealers; the active radius fully controls which dealers appear.
- Each dealer card has a button to open a contact form.
- Dealer cards show opening-hours context from API hours data (`Today, ...`) in condensed and selected states.
- Dealer-card Google Maps links use the active search center as `origin` when a search center exists.
- On desktop, filter panel and contact form open as full-height overlays inside the sidebar area.
- Desktop overlay height is based on the sidebar drawer shell, not on the current dealer-list content height; sparse-result states must still open the filter panel and contact form at full drawer height.
- On desktop, sidebar collapse hides the whole sidebar panel and keeps the toggle button visible outside the panel.
- When collapsed, the expand action uses a top-left `Show List` button pattern (icon + label).
- Sidebar hide/show control is desktop-only.
- Dealer card behavior is stateful:
- inactive cards show condensed summary
- hover highlights card border
- selected card expands to full details (hours, address, links, phone) and CTA
- selected card hours row includes a button that toggles a simple weekly-hours list (Monday to Sunday)
- Contact form supports default, invalid-field, and submitted states.

Mobile behavior:
- Dealer locator is split vertically:
- Controls section (search input, filter button, slider) above the map.
- Map section with right-side map controls.
- Dealer list section below the map.
- Contact form opens as a modal-style form with the same field/state model as desktop.
- Mobile filter and contact form overlays are constrained to the widget container, not the browser viewport.

## Core Constraints

- Build target is a Vite React TypeScript widget bundle.
- Host integration model is `mount(el, options)`.
- Runtime options flow through `ConfigContext` only.
- Volvo Design System packages, tokens, icons, and React wrappers are mandatory.
- Dealers are not shown before search.

For the full implementation ruleset, use:
- `docs/ai/ai-rules.md`
- `docs/ai/project-context.md`
- `docs/ai/architecture.md`

## Data Source

Current configurable test endpoint:
- `https://dealerlocator.macktrucks.com/Mack_DealerJson.ashx?state=1`

Current source support:
- dual-source schema support with runtime auto-detection:
- legacy Mack payload: `countries.*.states.*.dealers.*`
- SharePoint payload: `data[]`
- shared HTTP transport normalizes both sources into one `Dealer` model through source adapters
- invalid or missing dealer coordinates are ignored during normalization
- SharePoint `Brand=BOTH` records are normalized as dual-brand dealers and included in both Volvo and Mack filters

Canonical data and normalization rules live in:
- `docs/ai/api-and-data-contract.md`
- `docs/ai/architecture.md`

## Current Repository Status

What exists now:
- Vite library build config in `vite.config.ts`.
- Embeddable entry in `src/embed.tsx` exposing `mount(el, options)`.
- `ConfigContext` foundation with typed mount options and defaults.
- Runtime mount options are sanitized before final config merge.
- Clean desktop shell with full-screen Google Maps background and floating sidebar/controls.
- Google Maps script loader and interactive zoom/location controls wired.
- `@volvo/vcdk-react` wrappers integrated for search, slider, form fields, radio options, CTA buttons, icon buttons, map FAB controls, and theme provider.
- Theme CSS is bootstrapped from `@volvo/vcdk/themes/all-primitive.css`, `@volvo/vcdk/themes/all-semantic.css`, and `@volvo/vcdk/themes/volvo/typefaces.css`.
- Runtime theme resolution is implemented through `mount(..., { theme })` -> `config.themeId` -> `ThemeProvider`.
- `App.tsx` reduced to container composition; UI split into atomic components and feature hooks.
- Google Maps visual styles extracted to `src/map/googleMapStyles.ts`.
- i18n initialized with `i18next` + `react-i18next` and `en-US` resource file.
- Dealer API repository is adapter-based: shared HTTP transport delegates source-specific payload traversal and normalization to a dedicated adapter.
- Dealer API repository auto-detects source payload shape and selects the matching adapter (`countries` object-map source vs `data[]` SharePoint source).
- Dealer list is empty until a search is submitted and geocoded.
- Search execution is wired to Enter submit + Google geocoding + radius/brand filtering.
- Center-on-user geolocation is wired to reverse geocoding + search-state update (with coordinate fallback label).
- Dealer cards and map markers are both driven directly from the full in-radius result set, keeping list/marker sync aligned to the active radius and brand filters.
- Dense map areas use Google Maps marker clustering so overlapping dealers group into count badges until the user zooms in.
- Map viewport fitting is tied to search center/range/filter commits so radius coverage stays visible after each update.
- Map marker lifecycle uses incremental diffing (add/remove changed markers only) instead of full teardown/recreate on each render.
- Sidebar control wiring is wrapper-first and callback-driven; only minimal Enter-key bridging is kept for `SearchField` parity.
- Dealer list/cards are memoized and in-radius filtering uses a single-pass pipeline to reduce render and allocation overhead.
- Accessibility hardening is implemented for overlays and status regions: filter/request dialogs support Escape close, initial focus is moved to dialog close action, focus is restored on close, and dialog naming uses `aria-labelledby`.
- Dealer list loading/empty states and map status use screen-reader live region semantics.
- Dealer cards render normalized `Today` hours using API department/day maps and compute `Open now` from current-day hours.
- `Open now` and `Today` hours are evaluated against dealer-local clock context (resolved timezone), not the viewer browser timezone.
- Timezone resolution uses `tz-lookup`, which is substantially more accurate than the previous state/longitude heuristic but can still be approximate near timezone borders.
- Dealer card selected state provides a simple toggle button that opens a floating weekly-hours list on top of the card.
- Filter drawer is implemented with staged apply/cancel behavior.
- Contact form modal is implemented with validation, success state, and configurable submit endpoint.
- Contact form submit payload always includes `id`, locale/dealer/referrer context, and submit metadata (`sourcePageUrl`, `submittedAt`, `submittedTimezone`, `submittedTimezoneOffsetMinutes`):
- legacy source -> `COMPANY_ID`
- SharePoint source -> `Dealer Code`
- missing source id -> `id: ""`
- receiver configuration and full field contract are documented in `docs/ai/contact-form-receiver-contract.md`
- Desktop sidebar collapse and mobile split layout are implemented.
- Session persistence is implemented for query/radius/distance unit/brand filter.
- SharePoint source currently leaves opening-hours fields undefined.
- TODO: implement SharePoint opening-hours normalization when the source provides hours data.

What is not implemented yet:
- Automated unit-test coverage for critical flows.
- Full focus-trap/tab-cycle enforcement inside filter and request dialogs.

## Runtime Config

```ts
export type DealerLocatorOptions = {
  apiBaseUrl?: string; // required at mount runtime
  contactFormPostUrl?: string; // POST endpoint returning { result: "success" | "error" }
  initialQuery?: string; // prefilled search value on first render
  range?: {
    min?: number; // default: 25
    max?: number; // default: 2000
    initialValue?: number; // default: 100
  };
  locale?: string; // default: "en-US" — supported: "en-US", "en-CA", "es-419", "fr-CA"
  theme?: string; // default: "volvo"
  googleMapsApiKey?: string; // required for Google Maps rendering
  map?: {
    defaultCenter?: { lat: number; lng: number }; // default: geographic center of the US
    defaultZoom?: number; // default: 4
    minZoom?: number; // default: 2
    maxZoom?: number; // default: 18
    scrollZoom?: boolean; // default: true — set to false to disable scroll-wheel zoom (page scrolls instead; Ctrl+scroll still zooms the map)
  };
};
```

All options flow through `ConfigContext` inside `mount(...)`. Values are sanitized before merge, so invalid or missing numbers fall back to safe defaults. `apiBaseUrl` is required for mounted widget usage; `mount(...)` logs a console error when it is missing.

Theme resolution contract:
- Brand aliases: `volvo`, `mack`, `renault` resolve to `*-light`.
- Full theme IDs: `volvo-light`, `volvo-dark`, `mack-light`, `mack-dark`, `renault-light`, `renault-dark`.
- Invalid values safely fall back to `volvo-light`.

## Google Maps Key (Development)

Local dev (`src/main.tsx`) currently uses:
- `VITE_GOOGLE_MAPS_API_KEY` when present.
- Temporary fallback key for development when env var is missing.

For widget hosts:
- Always pass `apiBaseUrl` and `googleMapsApiKey` via `mount(el, options)`.

Local dev API wiring:
- `src/main.tsx` reads `VITE_API_BASE_URL`, `VITE_CONTACT_FORM_POST_URL`, and `VITE_THEME` and forwards them to `AppRoot` mount options.
- `npm run dev` (or `npm run dev:legacy`) starts Vite with the legacy profile.
- `npm run dev -- sharepoint` switches the default command to the SharePoint profile.
- `npm run dev:sharepoint` starts Vite with the SharePoint profile.
- `npm run dev:api -- "<api-url>"` starts Vite through the same script with a custom API URL.
- Extra Vite flags can be forwarded (example: `npm run dev -- sharepoint --host`).
```bash
# Standard legacy profile
npm run dev

# Override default profile through the same command
npm run dev -- sharepoint

# Explicit profile commands
npm run dev:legacy
npm run dev:sharepoint

# Custom endpoint URL
npm run dev:api -- "https://example.com/dealers"
```

```ts
import { mount } from "@volvo/vg-dealer-locator";

const unmount = mount(containerElement, {
  googleMapsApiKey: "YOUR_KEY",
});
```

For embedded usage, ensure `containerElement` has an explicit height. The widget fills the mount element with `width: 100%` and `height: 100%`.

## AI Documentation

Detailed implementation docs are in `docs/ai/`:
- `docs/ai/README.md`
- `docs/ai/ai-rules.md`
- `docs/ai/project-context.md`
- `docs/ai/architecture.md`
- `docs/ai/ui-spec.md`
- `docs/ai/breakpoints.md`
- `docs/ai/api-and-data-contract.md`
- `docs/ai/contact-form-receiver-contract.md`
- `docs/ai/roadmap.md`
- `docs/ai/figma-dealer-locator-reference.md`
- `docs/ai/testing.md`

## Local Commands

```bash
npm run dev
npm run dev:legacy
npm run dev:sharepoint
npm run dev:api -- "<api-url>"
npm run build
npm run lint
npm run lint:styles
npm run preview
npm run test:unit
npm run test:unit:coverage
npm run verify:quick
npm run verify:standard
npm run verify:full
npm run verify:impacted
npm run test:e2e:smoke
npm run test:e2e
npm run test:e2e:ui
npm run test:e2e:headed
```

## End-to-End Testing

Playwright E2E coverage is implemented for the widget-first integration path.

- Tests run against a host-style fixture page that imports the widget and calls `mount(el, options)`.
- Chromium is the only browser engine in the initial matrix.
- The Playwright projects are mobile-first:
- `mobile-chromium`
- `desktop-chromium`
- Shared user flows are covered on both mobile and desktop; desktop-only assertions are limited to desktop-only UI such as the collapsible sidebar shell and independent desktop results-pane scrolling.
- Dealer API responses, contact form submissions, and Google Maps/geocoding are mocked for deterministic runs.
- The E2E fixture lives under `tests/e2e/fixtures/widget-host/`.

Use these commands:

```bash
npm run test:e2e:smoke
npm run test:e2e
npm run test:e2e:ui
npm run test:e2e:headed
```

## Package Output

The published/packed artifact is expected to ship the built `dist/` directory only.

- `npm pack` runs `prepack`, which triggers `npm run build` before the tarball is created.
- `package.json` whitelists `dist/`, so the tarball includes:
- `dist/vg-dealer-locator.es.js`
- `dist/vg-dealer-locator.umd.js`
- `dist/vg-dealer-locator.css`

Host projects can consume the package from the root entry:

```ts
import { mount } from "@volvo/vg-dealer-locator";
import "@volvo/vg-dealer-locator/dist/vg-dealer-locator.css";
```

The widget root element uses the module-scoped class name `vg-dealer-locator`.

Direct deep import of `dist/vg-dealer-locator.es.js` is also supported for compatibility, but the root package entry should be preferred.
